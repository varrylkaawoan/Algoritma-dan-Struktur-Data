#include <stdio.h>
#include <stdlib.h>

// Function to mark the positions reachable by the knight
void koboImaginaryChess(int i, int j, int size, int *chessBoard) {
    // Array to represent possible moves of a knight
    int moves[8][2] = {{-2, -1}, {-2, 1}, {-1, -2}, {-1, 2},
                       {1, -2}, {1, 2}, {2, -1}, {2, 1}};

    // Check and mark reachable positions
    for (int k = 0; k < 8; k++) {
        int ni = i + moves[k][0];
        int nj = j + moves[k][1];
        if (ni >= 0 && ni < size && nj >= 0 && nj < size) {
            chessBoard[ni * size + nj] = 1;
        }
    }
}

int main() {
    // Allocate memory for chess board
    int *chessBoard = (int *)malloc(8 * 8 * sizeof(int));
    if (chessBoard == NULL) {
        printf("Memory allocation failed\n");
        return 1;
    }

    // Initialize chess board with zeros
    for (int i = 0; i < 8 * 8; i++) {
        chessBoard[i] = 0;
    }

    // Input the position of the knight
    int i, j;
    printf("Enter the position of the knight (i j): ");
    scanf("%d %d", &i, &j);

    // Call function to mark reachable positions
    koboImaginaryChess(i, j, 8, chessBoard);

    // Mark the position of the knight
    chessBoard[i * 8 + j] = 0;

    // Print the chess board
    printf("Chess board:\n");
    for (int row = 0; row < 8; row++) {
        for (int col = 0; col < 8; col++) {
            printf("%d ", chessBoard[row * 8 + col]);
        }
        printf("\n");
    }

    // Free dynamically allocated memory
    free(chessBoard);

    return 0;
}